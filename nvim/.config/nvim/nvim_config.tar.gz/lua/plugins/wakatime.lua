return {
  { 'wakatime/vim-wakatime', lazy = false },
}

